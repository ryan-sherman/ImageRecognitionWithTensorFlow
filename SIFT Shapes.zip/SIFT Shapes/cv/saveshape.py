import cv2
import numpy as np
import nninput
import time
import random
import json

def api(queue, room, image, tag, istraining):
    image = np.array(image).astype(np.uint8)
    run(image, tag, istraining)
    queue.put((room, "saved", True))

def run(image, tag, istraining):

    folder = "training" if istraining is 1 else "testing"
    id = "%s/%d-%d%d" % (folder, int(tag), time.time() * 1000, random.randint(10000, 99999))
    imname = "./images/%s.png" % (id)
    cv2.imwrite(imname, image)

    nn, _, _ = nninput.run(image, 8)
    nnname = "./inputs/%s.json" % (id)
    output = open(nnname, 'wb')
    json.dump(nn, output)
    output.close()
