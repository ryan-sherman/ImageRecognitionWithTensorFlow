import cv2
import math
import numpy as np
import sift
import pca

def api(queue, room, image, count):
    image = np.array(image).astype(np.uint8)
    nn, mean, angle = run(image, count)
    queue.put((room, "nnresult", {"mean": mean, "angle": angle, "desc": nn}))

def run(image, count):

    width, height = image.shape
    kps, descs = sift.run(image)
    mean, angle = pca.run(image)

    # Take the top count items and then sort them radially around the mean starting at the PC
    response_key = cmp_to_key(lambda (x): kps[x].response)
    kpindex = sorted(range(len(kps)), reverse = True, key=response_key)
    kpindex = kpindex[:count]

    def radial_compare(x):
        pt = kps[x].pt
        ptangle = math.atan2(pt[0] - mean[0], pt[1] - mean[1]) * (180 / 3.141592)
        if ptangle < angle: ptangle += 360
        return ptangle - angle

    kpindex = sorted(kpindex, key = cmp_to_key(radial_compare))

    # The strongest signals may come directly from the PCA
    points = [
        mean[0] / width,
        mean[1] / height,
        angle
    ]

    for x in kpindex:
        kp = kps[x]
        desc = descs[x].tolist()

        distance = np.linalg.norm(np.array(kp.pt) - mean)
        desc.insert(0, kp.size)
        desc.insert(0, distance)

        ptangle = math.atan2(kp.pt[0] - mean[0], kp.pt[1] - mean[1]) * (180 / 3.141592)
        if ptangle < angle: ptangle += 360
        desc.insert(0, ptangle - angle)

        points.extend(desc)

    # Fill in everything else with zeros
    for i in xrange(len(kpindex), count):
        points.extend(np.zeros(131).tolist())

    return points, mean.tolist(), angle


def cmp_to_key(mycmp):
    'Convert a cmp= function into a key= function'
    class K(object):
        def __init__(self, obj, *args):
            self.obj = obj
        def __lt__(self, other):
            return mycmp(self.obj) <  mycmp(other.obj)
    return K
