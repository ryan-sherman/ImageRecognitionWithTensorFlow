import cv2
import numpy as np

def api(queue, room, image):
    image = np.array(image).astype(np.uint8)
    kp, des = run(image)

    jskp = []
    for point in kp:
        jskp.append({
            "pt": point.pt, "size": point.size,
            "angle": point.angle,
            "quality": point.response
        })

    queue.put((room, "siftresult", jskp))

def run(image):
    # Run SIFT (this is really just too easy)
    sift = cv2.SIFT()
    kp1, des1 = sift.detectAndCompute(image, None)

    # Don't know why this is necessary
    kp1 = kp1[::2]

    return kp1, des1
