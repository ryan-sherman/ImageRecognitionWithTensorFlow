import cv2
import math
import numpy as np
from numpy import linalg

def api(queue, room, image):
    image = np.array(image).astype(np.uint8)
    midpoint, angle = run(image)
    midpoint = midpoint.tolist()
    queue.put((room, "pcaresult", [midpoint, angle]))


def run(image):

    # Use thresholding generate a perfect mask of the image
    ret, mask = cv2.threshold(255 - image,127,255,0)
    mean = maskCenterPoint(mask)
    midpoint, angle = maskPrincipalComponentAngle(mask)
    return midpoint, angle


# Find the center point of the visible portions of a mask
def maskCenterPoint(maskImage):
    locations = np.nonzero(maskImage)
    return np.mean(locations, axis = 1)


# Find the principal component of the mask
def maskPrincipalComponentAngle(maskImage):
    midpoint = maskCenterPoint(maskImage)
    pts = np.swapaxes(np.nonzero(maskImage),1,0) - midpoint

    # Get the Angle as X and Y components
    U, s, V = np.linalg.svd(pts,full_matrices=False)
    assert s[0] > s[1] # Make sure we're looking at the right eigenvector
    xyAngle = V[1][::-1] # Theta is actually orthogonal to the eigenvector

    # Get the angle as an angle
    radAngle = math.atan2(xyAngle[0],xyAngle[1])
    degAngle = (radAngle/(2*math.pi) * 360) % 180
    return (midpoint, degAngle)
