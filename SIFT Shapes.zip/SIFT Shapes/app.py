# FLASK + WEB SOCKETS ======================================================================
from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'LZ2b01d739P53pvnoD8j1YgZO0oA6YVP'
socketio = SocketIO(app)

@socketio.on("join")
def joinRoom(name):
    join_room(name)
    emit("joinsuccess")


# MULTITHREADING ===========================================================================

from multiprocessing import Process, Queue
wsQueue = Queue()

@socketio.on("ping")
def dispatchFromQueue():
    try:
        result = wsQueue.get(False)
        socketio.emit(result[1], result[2], room=result[0])
    except:
        pass


# API ROUTING ==============================================================================

# Static Routing
@app.route('/')
def root():
    return app.send_static_file('index.html')

# Computer Vision API
import cv
@app.route('/cv/sift', methods=['POST'])
def cvSift():
    room = request.form["room"]
    image = json.loads(request.form["image"])

    p = Process(target=cv.sift.api, args=(wsQueue, room, image))
    p.start()

    socketio.emit("receivedImage", room = room)
    return "GOOD"

@app.route('/cv/pca', methods=['POST'])
def cvPca():
    room = request.form["room"]
    image = json.loads(request.form["image"])

    p = Process(target=cv.pca.api, args=(wsQueue, room, image))
    p.start()

    socketio.emit("receivedImage", room = room)
    return "GOOD"

@app.route('/cv/nninput', methods=['POST'])
def cvnn():
    room = request.form["room"]
    count = 8
    image = json.loads(request.form["image"])

    p = Process(target=cv.nninput.api, args=(wsQueue, room, image, count))
    p.start()

    socketio.emit("receivedImage", room = room)
    return "GOOD"

@app.route('/addshape', methods=['POST'])
def addshape():
    room = request.form["room"]
    tag = request.form["tag"]
    istraining = int(request.form["set"])
    image = json.loads(request.form["image"])

    p = Process(target=cv.saveshape.api, args=(wsQueue, room, image, tag, istraining))
    p.start()

    socketio.emit("receivedImage", room = room)
    return "GOOD"


# Cognitive Computing API
import nn
@app.route('/train/standard', methods=['POST'])
def trainstandard():
    room = request.form["room"]
    iterations = int(request.form["iterations"])

    p = Process(target=nn.train_standard.api, args=(wsQueue, room, iterations))
    p.start()

    return "GOOD"

@app.route('/train/2sigmoid', methods=['POST'])
def trainrelu():
    room = request.form["room"]
    iterations = int(request.form["iterations"])

    p = Process(target=nn.train_2sigmoid.api, args=(wsQueue, room, iterations, 64))
    p.start()

    return "GOOD"


# GO GO GO =================================================================================
if __name__ == '__main__':
    app.debug = True
    socketio.run(app)
